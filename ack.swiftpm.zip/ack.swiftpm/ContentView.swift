
//
//  ContentView.swift
//  stacks 2
//
//  Created by John T. Arvanites on 9/8/23.
//

import Foundation
import SwiftUI

    struct ContentView: View {
        var body: some View {
            VStack(){
                
                Text("                               0")
                    .font(.title)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .frame(width: 300.0, height: 50.0)
                
                
                
                
                HStack {
                    VStack{
                        Button(action: {}, label: {
                            Text("AC")
                            .foregroundColor(Color.black)}).frame(width: 50, height: 50).background(Color(hue: 1.0, saturation: 0.0, brightness: 0.711)).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("7")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("4")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("1")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        
                        
                    }
                    VStack{
                        Button(action: {}, label: {
                            Text("+/-")
                            .foregroundColor(Color.black)}).frame(width: 50, height: 50).background(Color(hue: 1.0, saturation: 0.0, brightness: 0.711)).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("8")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("5")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("2")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        
                        
                    }
                    VStack{
                        Button(action: {}, label: {
                            Text("%")
                            .foregroundColor(Color.black)}).frame(width: 50, height: 50).background(Color(hue: 1.0, saturation: 0.0, brightness: 0.711)).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("9")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("6")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("3")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        
                        
                    }
                    VStack{
                        Button(action: {}, label: {
                            Text("/")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.orange).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("x")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.orange).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("-")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.orange).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        Button(action: {}, label: {
                            Text("+")
                            .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.orange).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        
                        
                    }
                    
                }
                HStack{
                    ZStack{
                        RoundedRectangle(cornerRadius: 80, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/).foregroundColor(.gray)
                            .frame(width: 110, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        Text("0").foregroundColor(.white)
                    }
                    Button(action: {}, label: {
                        Text(".")
                        .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.gray).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    Button(action: {}, label: {
                        Text("=")
                        .foregroundColor(Color.white)}).frame(width: 50, height: 50).background(.orange).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    
                }
            }.frame(width: 9999, height: 9999).background(.black).scaleEffect(/*@START_MENU_TOKEN@*/1.5/*@END_MENU_TOKEN@*/)
        }
    }
    

