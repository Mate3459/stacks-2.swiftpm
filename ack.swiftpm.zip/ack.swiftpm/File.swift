//
//  File.swift
//  stacks 2
//
//  Created by Mate B. Szep on 9/12/23.
//

import Foundation
import SwiftUI

struct File: View {
    var body: some View {
        VStack{
            Rectangle()
                .frame(width: 50, height: 30)
                .cornerRadius(10)
                .foregroundColor(.green)
            Circle()
                .frame(width: 20, height: 30)
                .foregroundColor(.blue)
            Ellipse()
                .frame(width: 50, height: 30)
            Capsule(style: .continuous)
                .frame(width: 50, height: 30)
                .foregroundColor(.purple)
            Capsule(style: .circular)
                .frame(width: 50, height: 30)
                .foregroundColor(.pink)
            RoundedRectangle(cornerRadius: 25)
                .frame(width: 20, height: 30)
                .foregroundColor(.mint)
        }
        
    }
}
